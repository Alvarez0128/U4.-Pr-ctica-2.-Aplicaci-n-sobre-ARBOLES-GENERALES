
public class NodoLiga {
    NodoGeneral direccion;
    NodoLiga ant,sig;
    
    public NodoLiga(NodoGeneral direccion){
        this.direccion=direccion;
        ant=sig=null;
    }
}
