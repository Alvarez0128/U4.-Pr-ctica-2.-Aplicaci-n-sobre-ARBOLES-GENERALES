
public class ArbolGeneral {
    NodoGeneral raiz;
    
    public ArbolGeneral(){
        raiz=null;
    }
    
    public boolean insertarNodoGeneral(String path, char valor){
        if(path.isEmpty()){
            if(raiz==null){
                raiz=new NodoGeneral(valor);
                return true;
            }
            return false;
        }
        
        NodoGeneral padre=buscarNodo(path);
        if(padre==null){
            return false;
        }
        
        NodoGeneral buscarhijo= buscarNodo(path+"/"+valor);
        if(buscarhijo!=null){
            return false;
        }
        NodoGeneral hijo=new NodoGeneral(valor);
        
        return padre.insertarLiga(hijo);
    }
    public char raiz(){
        return raiz.valor;
    }
    
    private NodoGeneral buscarNodo(String path){
        if(path.isEmpty()){
            return null;
        }        
        path=path.substring(1);
        String[] vector=path.split("/");
        
        if(raiz.valor==vector[0].charAt(0)){
            if(vector.length==1){
                return raiz;
            }
            for(NodoLiga temp=raiz.ini;temp!=null;temp=temp.sig){
                if(temp.direccion.valor==vector[1].charAt(0)){
                    if(vector.length==2){
                        return temp.direccion;
                    }
                    return buscarNodo(temp.direccion,path.substring(3));
                }
            }
        }
        return null;
    }
    private NodoGeneral buscarNodo(NodoGeneral nodoEncontrado, String path){
        //CASO BASE
        if(path.isEmpty()){
            return nodoEncontrado;
        }
        path=path.substring(1);
        String[] vector;
        if(path.length()==1){
            vector=new String[1];
            vector[0]=path;
        } else {
            vector=path.split("/");
        }
        
        for(NodoLiga temp=nodoEncontrado.ini; temp!=null;temp=temp.sig){
            if(temp.direccion.valor==vector[0].charAt(0)){
                buscarNodo(temp.direccion, path.substring(1));
            }
        }
        return null;
    }
    
        
    public boolean eliminarNodoGeneral(String path){
        NodoGeneral nodoAEliminar = buscarNodo(path);
        if(nodoAEliminar==null){
            return false;
        }
        if(nodoAEliminar==raiz){
            if(raiz.esHoja()){
                raiz=null;
                return true;
            }
            return false;
        }
        String pathPadre=obtenerPathPadre(path);
        NodoGeneral padre=buscarNodo(pathPadre);
        if(padre==null){
            return false;
        }
        if(nodoAEliminar.esHoja()){
            return padre.eliminarLiga(nodoAEliminar);
        }
        
        return false;
    }
    private String obtenerPathPadre(String pathHijo){
        int posicionUltimaDiagonal = pathHijo.lastIndexOf("/");
        return pathHijo.substring(0, posicionUltimaDiagonal);
    } 
    public NodoGeneral padre(String path){
        String p=obtenerPathPadre(path);
        NodoGeneral padre=buscarNodo(p);
        if(padre.valor==raiz.valor){
            return raiz;
        }
        return padre;
    }
    public boolean consulta(String path){
        return buscarNodo(path) != null;
    }
    public String mostrarNodos(){
        if(raiz==null){
            return "No hay nodos";
        }
        return mostrarNodos(raiz.ini);
    }
    public String mostrarNodos(NodoLiga temp){
        if(temp==null){
            return "";
        }
        return "    "+temp.direccion.valor+"\n"+mostrarNodos(temp.sig);
    }
    
    
}
